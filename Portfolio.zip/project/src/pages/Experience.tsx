import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin } from 'lucide-react';

const experiences = [
  {
    id: 1,
    role: "Biomedical Engineer",
    company: "Medical Innovations Lab",
    duration: "2022 - Present",
    location: "Boston, MA",
    description: "Leading research and development of innovative medical devices and imaging solutions."
  },
  {
    id: 2,
    role: "Software Engineer",
    company: "HealthTech Solutions",
    duration: "2020 - 2022",
    location: "San Francisco, CA",
    description: "Developed healthcare applications and implemented machine learning algorithms for medical data analysis."
  },
  {
    id: 3,
    role: "Research Assistant",
    company: "University Research Lab",
    duration: "2019 - 2020",
    location: "Cambridge, MA",
    description: "Conducted research on biomedical signal processing and developed analysis tools."
  }
];

const Experience = () => {
  return (
    <div className="min-h-screen pt-16 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-center mb-16 text-white"
        >
          Professional Experience
        </motion.h2>

        <div className="space-y-12">
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-gray-800 rounded-lg p-8 shadow-xl"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-white">{exp.role}</h3>
                  <p className="text-xl text-blue-400">{exp.company}</p>
                </div>
                <div className="flex flex-col md:items-end mt-2 md:mt-0">
                  <div className="flex items-center text-gray-400">
                    <Calendar size={16} className="mr-2" />
                    {exp.duration}
                  </div>
                  <div className="flex items-center text-gray-400 mt-1">
                    <MapPin size={16} className="mr-2" />
                    {exp.location}
                  </div>
                </div>
              </div>
              <p className="text-gray-400">{exp.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Experience;