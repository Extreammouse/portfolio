import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Award } from 'lucide-react';

const Education = () => {
  return (
    <div className="min-h-screen pt-16 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-center mb-16 text-white"
        >
          Education
        </motion.h2>

        <div className="space-y-12">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gray-800 rounded-lg p-8 shadow-xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-white">Master of Science in Biomedical Engineering</h3>
                <p className="text-xl text-blue-400">Massachusetts Institute of Technology</p>
              </div>
              <div className="flex items-center text-gray-400">
                <Calendar size={16} className="mr-2" />
                2020 - 2022
              </div>
            </div>
            <div className="space-y-2 text-gray-400">
              <p>• Specialized in Medical Imaging and Device Development</p>
              <p>• Research Focus: AI in Healthcare</p>
              <p>• GPA: 3.95/4.0</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gray-800 rounded-lg p-8 shadow-xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-white">Bachelor of Science in Computer Science</h3>
                <p className="text-xl text-blue-400">Stanford University</p>
              </div>
              <div className="flex items-center text-gray-400">
                <Calendar size={16} className="mr-2" />
                2016 - 2020
              </div>
            </div>
            <div className="space-y-2 text-gray-400">
              <p>• Minor in Bioengineering</p>
              <p>• Dean's List: All Semesters</p>
              <p>• Senior Thesis: Machine Learning in Medical Diagnostics</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gray-800/50 rounded-lg p-8"
          >
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Award className="mr-2" />
              Certifications & Achievements
            </h3>
            <ul className="space-y-2 text-gray-400">
              <li>• AWS Certified Solutions Architect</li>
              <li>• Deep Learning Specialization - Coursera</li>
              <li>• Medical Device Development Certificate - FDA</li>
            </ul>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default Education;