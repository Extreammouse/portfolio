import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, FileDown, Github, Linkedin } from 'lucide-react';

const ContactItem = ({ icon: Icon, title, content, href, delay }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      whileHover={{ scale: 1.05 }}
      transition={{ delay, duration: 0.3 }}
      className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-gray-800/50 to-gray-700/50 backdrop-blur-sm p-6 hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="flex items-center space-x-4 relative z-10">
        <div className="p-3 rounded-full bg-gradient-to-r from-blue-500/20 to-purple-500/20 group-hover:from-blue-500/30 group-hover:to-purple-500/30 transition-all duration-300">
          <Icon className="text-blue-400 group-hover:text-blue-300 transition-colors duration-300" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white group-hover:text-blue-300 transition-colors duration-300">{title}</h3>
          {href ? (
            <a 
              href={href}
              target={href.startsWith('http') ? "_blank" : undefined}
              rel={href.startsWith('http') ? "noopener noreferrer" : undefined}
              className="text-gray-400 hover:text-blue-400 transition-colors duration-300"
            >
              {content}
            </a>
          ) : (
            <p className="text-gray-400">{content}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
};

const Contact = () => {
  const contactItems = [
    { icon: Mail, title: "Email", content: "contact@example.com", href: "mailto:contact@example.com", delay: 0.1 },
    { icon: Phone, title: "Phone", content: "+1 (555) 123-4567", href: "tel:+15551234567", delay: 0.2 },
    { icon: MapPin, title: "Location", content: "Boston, Massachusetts", delay: 0.3 },
    { icon: Github, title: "GitHub", content: "github.com/yourusername", href: "https://github.com/yourusername", delay: 0.4 },
    { icon: Linkedin, title: "LinkedIn", content: "linkedin.com/in/yourusername", href: "https://linkedin.com/in/yourusername", delay: 0.5 }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text"
      >
        Get in Touch
      </motion.h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {contactItems.map((item, index) => (
          <ContactItem key={index} {...item} />
        ))}
        
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.05 }}
          transition={{ delay: 0.6, duration: 0.3 }}
          className="md:col-span-2"
        >
          <a
            href="/resume.pdf"
            download
            className="block w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl text-center font-semibold shadow-lg hover:shadow-blue-500/25 transition-all duration-300"
          >
            <div className="flex items-center justify-center space-x-2">
              <FileDown size={20} />
              <span>Download Resume</span>
            </div>
          </a>
        </motion.div>
      </div>
    </div>
  );
}

export default Contact;