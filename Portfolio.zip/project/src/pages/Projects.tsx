import React from 'react';
import { motion } from 'framer-motion';

// This array can be expanded with more projects
const projects = [
  {
    id: 1,
    title: "Medical Imaging AI",
    description: "Deep learning solution for medical image analysis using TensorFlow and PyTorch.",
    image: "https://images.unsplash.com/photo-1576670159805-861a1b6f96ab?auto=format&fit=crop&q=80",
    tags: ["Python", "TensorFlow", "Medical Imaging"]
  },
  {
    id: 2,
    title: "Patient Monitoring System",
    description: "Real-time patient monitoring system with IoT sensors and cloud integration.",
    image: "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80",
    tags: ["IoT", "Cloud", "React"]
  },
  {
    id: 3,
    title: "Biomedical Data Analytics",
    description: "Advanced analytics platform for processing and visualizing biomedical data.",
    image: "https://images.unsplash.com/photo-1518152006812-edab29b069ac?auto=format&fit=crop&q=80",
    tags: ["Data Analysis", "Python", "Visualization"]
  }
  // Add more projects here as needed
];

const ProjectCard = ({ project, index }) => {
  const isEven = index % 2 === 0;
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className={`flex flex-col ${isEven ? 'md:flex-row' : 'md:flex-row-reverse'} items-center gap-8`}
    >
      <motion.div
        initial={isEven ? { x: -100, opacity: 0 } : { x: 100, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.2 }}
        whileHover={{ scale: 1.05 }}
        className="w-full md:w-1/2 overflow-hidden rounded-lg"
      >
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-[300px] object-cover transform hover:scale-110 transition-transform duration-500"
        />
      </motion.div>

      <motion.div
        initial={isEven ? { x: 100, opacity: 0 } : { x: -100, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="w-full md:w-1/2 space-y-4"
      >
        <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
          {project.title}
        </h3>
        <p className="text-gray-400">{project.description}</p>
        <div className="flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 bg-gradient-to-r from-blue-500/10 to-purple-500/10 text-blue-400 rounded-full text-sm hover:from-blue-500/20 hover:to-purple-500/20 transition-all duration-300"
            >
              {tag}
            </span>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};

const Projects = () => {
  return (
    <div className="max-w-7xl mx-auto px-4">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text"
      >
        Featured Projects
      </motion.h2>

      <div className="space-y-24">
        {projects.map((project, index) => (
          <ProjectCard key={project.id} project={project} index={index} />
        ))}
      </div>
    </div>
  );
}

export default Projects;